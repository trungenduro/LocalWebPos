import fs from 'node:fs/promises'

function cleanEnv(s) {
  const t = String(s || '').trim()
  if ((t.startsWith('"') && t.endsWith('"')) || (t.startsWith("'") && t.endsWith("'"))) {
    return t.slice(1, -1).trim()
  }
  return t
}

export function isFacebookEnabled() {
  const enabled = cleanEnv(process.env.FB_POST_ENABLED)
  if (enabled.length === 0) return false
  if (enabled === '1' || enabled.toLowerCase() === 'true' || enabled.toLowerCase() === 'yes')
    return true
  return false
}

export function getFacebookConfig() {
  return {
    pageId: cleanEnv(process.env.FB_PAGE_ID),
    pageAccessToken: cleanEnv(process.env.FB_PAGE_ACCESS_TOKEN),
    apiVersion: cleanEnv(process.env.FB_API_VERSION) || 'v20.0',
  }
}

export function buildFacebookCaption({ analysis }) {
  const dir =
    analysis?.entryPlan?.direction === 'long'
      ? 'MUA'
      : analysis?.entryPlan?.direction === 'short'
        ? 'BÁN'
        : 'TRUNG LẬP'

  const lines = [
    `${analysis.symbol} (${analysis.timeframe})`,
    '',
    `Sóng hiện tại: ${analysis.currentWave}`,
    analysis.alternateCount ? `Phương án khác: ${analysis.alternateCount}` : null,
    '',
    `Kế hoạch vào lệnh: ${dir}`,
    `Điểm vào: ${analysis.entryPlan.entry}`,
    `Vô hiệu: ${analysis.entryPlan.invalidation}`,
    `Mục tiêu: ${analysis.entryPlan.target}`,
    '',
    `Độ tin cậy: ${Math.round(Math.max(0, Math.min(1, Number(analysis.confidence || 0))) * 100)}%`,
  ].filter(Boolean)

  return lines.join('\n')
}

export async function postScreenshotToFacebookPage({
  fileName,
  absPath,
  caption,
  pageId,
  pageAccessToken,
  apiVersion = 'v20.0',
}) {
  if (!pageId || !pageAccessToken) {
    throw new Error('Thiếu FB_PAGE_ID hoặc FB_PAGE_ACCESS_TOKEN')
  }

  const url = `https://graph.facebook.com/${apiVersion}/${encodeURIComponent(pageId)}/photos`
  const buf = await fs.readFile(absPath)

  const form = new FormData()
  form.append('access_token', pageAccessToken)
  form.append('caption', caption || '')
  form.append('published', 'true')
  form.append('source', new Blob([buf], { type: 'image/png' }), fileName)

  const res = await fetch(url, { method: 'POST', body: form })
  const data = await res.json().catch(() => null)
  if (!res.ok) {
    const msg = data?.error?.message ? String(data.error.message) : `HTTP ${res.status}`
    throw new Error(msg)
  }
  return data
}

