const els = {
  folder: document.getElementById('folder'),
  error: document.getElementById('error'),
  count: document.getElementById('count'),
  list: document.getElementById('list'),
  status: document.getElementById('status'),
  analyzeBtn: document.getElementById('analyzeBtn'),
  noAnalysis: document.getElementById('noAnalysis'),
  analysisError: document.getElementById('analysisError'),
  analysisReady: document.getElementById('analysisReady'),
  currentWave: document.getElementById('currentWave'),
  alternate: document.getElementById('alternate'),
  confPct: document.getElementById('confPct'),
  confBar: document.getElementById('confBar'),
  dir: document.getElementById('dir'),
  entry: document.getElementById('entry'),
  inv: document.getElementById('inv'),
  tgt: document.getElementById('tgt'),
  summary: document.getElementById('summary'),
  chartCard: document.getElementById('chartCard'),
  chartImg: document.getElementById('chartImg'),
  chartMeta: document.getElementById('chartMeta'),
  versionSelect: document.getElementById('versionSelect'),
  langSelect: document.getElementById('langSelect'),
  refreshBtn: document.getElementById('refreshBtn'),
  autoRefresh: document.getElementById('autoRefresh'),
  autoAnalyze: document.getElementById('autoAnalyze'),
  intervalSec: document.getElementById('intervalSec'),
}

let state = {
  folder: '',
  items: [],
  symbols: [],
  selectedSymbol: null,
  selectedFileName: null,
  analysisByFile: new Map(),
  lastSeenMtimeByFile: new Map(),
  changedFiles: new Set(),
  timer: null,
  analyzing: false,
  lang: 'vi',
}

let timeOffsetHours = 0

const I18N = {
  vi: {
    appTitle: 'Wave Desk',
    refresh: 'Làm mới',
    autoRefresh: 'Tự làm mới',
    autoAnalyze: 'Tự phân tích',
    minutes: 'phút',
    listTitle: 'Danh sách',
    analysisTitle: 'Phân tích',
    selectVersionTitle: 'Chọn phiên bản',
    versionPlaceholder: 'Phiên bản',
    analyze: 'Phân tích',
    noAnalysis: 'Chưa có kết quả. Bấm “Phân tích”.',
    currentWaveLabel: 'Sóng hiện tại',
    confidenceLabel: 'độ tin cậy',
    entryPlanLabel: 'Kế hoạch vào lệnh',
    directionLabel: 'Hướng',
    entryLabel: 'Điểm vào',
    invalidationLabel: 'Vô hiệu',
    targetLabel: 'Mục tiêu',
    summaryLabel: 'Tóm tắt',
    chartLabel: 'Chart',
    status_idle: 'chờ',
    status_loading: 'đang phân tích',
    status_ready: 'xong',
    status_error: 'lỗi',
    altPrefix: 'Phương án khác',
    unknown: 'không rõ',
    n_a: 'n/a',
    dir_long: 'mua',
    dir_short: 'bán',
    dir_neutral: 'trung lập',
    noScreenshots: 'Không tìm thấy ảnh chụp.',
    folderNotConfigured: 'Chưa cấu hình thư mục',
    loadListFailed: 'Tải danh sách thất bại',
    refreshFailed: 'Làm mới thất bại',
    analyzeFailed: 'Phân tích thất bại',
  },
  en: {
    appTitle: 'Wave Desk',
    refresh: 'Refresh',
    autoRefresh: 'Auto refresh',
    autoAnalyze: 'Auto analyze',
    minutes: 'min',
    listTitle: 'Symbols',
    analysisTitle: 'Analysis',
    selectVersionTitle: 'Select version',
    versionPlaceholder: 'Version',
    analyze: 'Analyze',
    noAnalysis: 'No result yet. Click “Analyze”.',
    currentWaveLabel: 'Current wave',
    confidenceLabel: 'confidence',
    entryPlanLabel: 'Entry plan',
    directionLabel: 'Direction',
    entryLabel: 'Entry',
    invalidationLabel: 'Invalidation',
    targetLabel: 'Target',
    summaryLabel: 'Summary',
    chartLabel: 'Chart',
    status_idle: 'idle',
    status_loading: 'analyzing',
    status_ready: 'ready',
    status_error: 'error',
    altPrefix: 'Alternate',
    unknown: 'unknown',
    n_a: 'n/a',
    dir_long: 'buy',
    dir_short: 'sell',
    dir_neutral: 'neutral',
    noScreenshots: 'No screenshots found.',
    folderNotConfigured: 'Folder not configured',
    loadListFailed: 'Failed to load list',
    refreshFailed: 'Refresh failed',
    analyzeFailed: 'Analyze failed',
  },
  ja: {
    appTitle: 'Wave Desk',
    refresh: '更新',
    autoRefresh: '自動更新',
    autoAnalyze: '自動分析',
    minutes: '分',
    listTitle: '銘柄一覧',
    analysisTitle: '分析',
    selectVersionTitle: 'バージョン選択',
    versionPlaceholder: 'バージョン',
    analyze: '分析',
    noAnalysis: '結果なし。「分析」を押してください。',
    currentWaveLabel: '現在の波',
    confidenceLabel: '信頼度',
    entryPlanLabel: 'エントリープラン',
    directionLabel: '方向',
    entryLabel: 'エントリー',
    invalidationLabel: '無効ライン',
    targetLabel: '目標',
    summaryLabel: '要約',
    chartLabel: 'チャート',
    status_idle: '待機',
    status_loading: '分析中',
    status_ready: '完了',
    status_error: 'エラー',
    altPrefix: '代替案',
    unknown: '不明',
    n_a: 'n/a',
    dir_long: '買い',
    dir_short: '売り',
    dir_neutral: '中立',
    noScreenshots: 'スクリーンショットが見つかりません。',
    folderNotConfigured: 'フォルダ未設定',
    loadListFailed: '一覧の読み込みに失敗',
    refreshFailed: '更新に失敗',
    analyzeFailed: '分析に失敗',
  },
}

function t(key) {
  return I18N[state.lang]?.[key] ?? I18N.vi[key] ?? key
}

function detectInitialLang() {
  const saved = (localStorage.getItem('waveDeskLang') || '').trim()
  if (saved === 'vi' || saved === 'en' || saved === 'ja') return saved
  const nav = String(navigator.language || '').toLowerCase()
  if (nav.startsWith('ja')) return 'ja'
  if (nav.startsWith('en')) return 'en'
  return 'vi'
}

function applyI18n() {
  document.documentElement.lang = state.lang
  if (els.langSelect) els.langSelect.value = state.lang

  const nodes = document.querySelectorAll('[data-i18n]')
  for (const el of nodes) {
    const key = el.getAttribute('data-i18n')
    if (!key) continue
    el.textContent = t(key)
  }

  const titleNodes = document.querySelectorAll('[data-i18n-title]')
  for (const el of titleNodes) {
    const key = el.getAttribute('data-i18n-title')
    if (!key) continue
    el.setAttribute('title', t(key))
  }
}

function setLanguage(lang) {
  state.lang = lang === 'en' || lang === 'ja' ? lang : 'vi'
  localStorage.setItem('waveDeskLang', state.lang)
  applyI18n()
  renderList()
  renderVersionSelect()
  renderAnalysis()
  void loadSavedAnalysis(state.selectedFileName)
}

function analysisKey(fileName) {
  const f = String(fileName || '')
  return `${state.lang}:${f}`
}

function pad2(n) {
  return String(n).padStart(2, '0')
}

function formatTsWithOffset(isoNoTz) {
  const s = String(isoNoTz || '').trim()
  const m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})$/.exec(s)
  if (!m) return s || ''
  const y = Number(m[1])
  const mo = Number(m[2]) - 1
  const d = Number(m[3])
  const hh = Number(m[4])
  const mm = Number(m[5])
  const ss = Number(m[6])
  const dt = new Date(Date.UTC(y, mo, d, hh, mm, ss) + timeOffsetHours * 60 * 60 * 1000)
  return `${dt.getUTCFullYear()}-${pad2(dt.getUTCMonth() + 1)}-${pad2(dt.getUTCDate())} ${pad2(dt.getUTCHours())}:${pad2(dt.getUTCMinutes())}:${pad2(dt.getUTCSeconds())}`
}

async function loadConfig() {
  try {
    const res = await fetch('/api/config')
    if (!res.ok) return
    const data = await res.json().catch(() => null)
    const n = Number(data?.timeOffsetHours ?? 0)
    timeOffsetHours = Number.isFinite(n) ? Math.max(-24, Math.min(24, n)) : 0
  } catch {
    timeOffsetHours = 0
  }
}

function setError(msg) {
  els.error.textContent = msg || ''
}

function setStatus(value) {
  const v = String(value || 'idle')
  const label = t(`status_${v}`)
  els.status.textContent = label || v
}

function showAnalysisIdle() {
  els.noAnalysis.classList.remove('hidden')
  els.analysisError.classList.add('hidden')
  els.analysisReady.classList.add('hidden')
  if (els.chartImg) els.chartImg.removeAttribute('src')
  if (els.chartMeta) els.chartMeta.textContent = ''
}

function showAnalysisError(msg) {
  els.noAnalysis.classList.add('hidden')
  els.analysisError.classList.remove('hidden')
  els.analysisReady.classList.add('hidden')
  els.analysisError.textContent = msg
  if (els.chartImg) els.chartImg.removeAttribute('src')
  if (els.chartMeta) els.chartMeta.textContent = ''
}

function showAnalysisReady(data) {
  els.noAnalysis.classList.add('hidden')
  els.analysisError.classList.add('hidden')
  els.analysisReady.classList.remove('hidden')

  const dirRaw = data?.entryPlan?.direction || 'neutral'
  const dirText = dirRaw === 'long' ? t('dir_long') : dirRaw === 'short' ? t('dir_short') : t('dir_neutral')

  els.currentWave.textContent = data.currentWave || t('unknown')
  els.alternate.textContent = data.alternateCount
    ? `${t('altPrefix')}: ${data.alternateCount}`
    : ''
  els.dir.textContent = dirText
  els.entry.textContent = data?.entryPlan?.entry || t('n_a')
  els.inv.textContent = data?.entryPlan?.invalidation || t('n_a')
  els.tgt.textContent = data?.entryPlan?.target || t('n_a')
  els.summary.textContent = data.summary || ''

  const conf = Math.max(0, Math.min(1, Number(data.confidence || 0)))
  const pct = Math.round(conf * 100)
  els.confPct.textContent = `${pct}%`
  els.confBar.style.width = `${pct}%`

  const fileName = data?.fileName || state.selectedFileName
  const it = state.items.find((x) => x.fileName === fileName) || null
  if (els.chartImg && fileName) {
    els.chartImg.src = `/api/screenshots/${encodeURIComponent(fileName)}?t=${Date.now()}`
  }
  if (els.chartMeta) {
    const tf = data?.timeframe || it?.timeframe || ''
    const sym = data?.symbol || it?.symbol || ''
    const ts = it?.capturedAt ? formatTsWithOffset(it.capturedAt) : ''
    els.chartMeta.textContent = `${sym}${tf ? ` ${tf}` : ''}${ts ? ` • ${ts}` : ''}`
  }
}

function renderList() {
  els.count.textContent = String(state.symbols.length)
  els.list.innerHTML = ''
  if (state.symbols.length === 0) {
    const div = document.createElement('div')
    div.className = 'dim'
    div.style.padding = '10px'
    div.textContent = t('noScreenshots')
    els.list.appendChild(div)
    return
  }

  for (const s of state.symbols) {
    const btn = document.createElement('button')
    btn.type = 'button'
    btn.className = `item${s.symbol === state.selectedSymbol ? ' active' : ''}`
    btn.addEventListener('click', () => selectSymbol(s.symbol))

    const main = document.createElement('div')
    main.className = 'itMain'

    const top = document.createElement('div')
    top.className = 'itTop'
    const sym = document.createElement('div')
    sym.className = 'sym'
    sym.textContent = s.symbol
    const tf = document.createElement('div')
    tf.className = 'tf'
    tf.textContent = s.timeframe
    top.appendChild(sym)
    top.appendChild(tf)

    const ts = document.createElement('div')
    ts.className = 'fn mono'
    ts.textContent = s.capturedAt ? formatTsWithOffset(s.capturedAt) : new Date(s.mtimeMs).toISOString()

    main.appendChild(top)
    main.appendChild(ts)

    btn.appendChild(main)
    els.list.appendChild(btn)
  }
}

function renderVersionSelect() {
  if (!els.versionSelect) return
  els.versionSelect.innerHTML = ''

  const sym = state.selectedSymbol
  if (!sym) {
    els.versionSelect.disabled = true
    const opt = document.createElement('option')
    opt.value = ''
    opt.textContent = t('versionPlaceholder')
    els.versionSelect.appendChild(opt)
    return
  }

  const files = state.items
    .filter((x) => x.symbol === sym)
    .slice()
    .sort((a, b) => b.mtimeMs - a.mtimeMs)

  els.versionSelect.disabled = files.length <= 1
  for (const it of files) {
    const opt = document.createElement('option')
    opt.value = it.fileName
    const ts = it.capturedAt ? formatTsWithOffset(it.capturedAt) : new Date(it.mtimeMs).toISOString()
    opt.textContent = `${it.timeframe} • ${ts}`
    if (it.fileName === state.selectedFileName) opt.selected = true
    els.versionSelect.appendChild(opt)
  }
}

function renderAnalysis() {
  const it = state.items.find((x) => x.fileName === state.selectedFileName) || null
  if (!it) {
    setStatus('idle')
    showAnalysisIdle()
    return
  }

  const st = state.analysisByFile.get(analysisKey(it.fileName))
  if (!st) {
    setStatus('idle')
    showAnalysisIdle()
    return
  }

  setStatus(st.status)
  if (st.status === 'error') showAnalysisError(st.error || 'Phân tích thất bại')
  else if (st.status === 'ready') showAnalysisReady(st.data)
  else showAnalysisIdle()
}

function selectSymbol(symbol) {
  state.selectedSymbol = symbol
  const latest =
    state.items
      .filter((x) => x.symbol === symbol)
      .slice()
      .sort((a, b) => b.mtimeMs - a.mtimeMs)[0] || null
  state.selectedFileName = latest?.fileName || null
  renderList()
  renderVersionSelect()
  renderAnalysis()
  void loadSavedAnalysis(state.selectedFileName)
}

function selectFile(fileName) {
  state.selectedFileName = fileName
  const it = state.items.find((x) => x.fileName === fileName) || null
  if (it) state.selectedSymbol = it.symbol
  renderList()
  renderVersionSelect()
  renderAnalysis()
  void loadSavedAnalysis(fileName)
}

async function loadSavedAnalysis(fileName) {
  try {
    if (!fileName) return
    const key = analysisKey(fileName)
    if (state.analysisByFile.has(key)) return
    const res = await fetch(
      `/api/analysis/${encodeURIComponent(fileName)}?lang=${encodeURIComponent(state.lang)}`,
    )
    if (!res.ok) return
    const data = await res.json()
    state.analysisByFile.set(key, {
      status: 'ready',
      mtimeMs: data.mtimeMs,
      data,
    })
    renderAnalysis()
  } catch {
    return
  }
}

async function refresh() {
  try {
    setError('')
    const res = await fetch('/api/screenshots')
    if (!res.ok) throw new Error(`${t('loadListFailed')}: ${res.status}`)
    const data = await res.json()
    state.folder = data.folder || ''
    state.items = Array.isArray(data.items) ? data.items : []
    els.folder.textContent = state.folder || t('folderNotConfigured')

    const symMap = new Map()
    for (const it of state.items) {
      const prev = symMap.get(it.symbol)
      if (!prev || it.mtimeMs > prev.mtimeMs) {
        symMap.set(it.symbol, it)
      }
    }
    state.symbols = Array.from(symMap.values()).sort((a, b) => b.mtimeMs - a.mtimeMs)

    const nextLastSeen = new Map(state.lastSeenMtimeByFile)
    const changed = new Set()
    for (const it of state.items) {
      const prevMtime = nextLastSeen.get(it.fileName)
      if (typeof prevMtime === 'number' && prevMtime !== it.mtimeMs) {
        changed.add(it.fileName)
      }
      nextLastSeen.set(it.fileName, it.mtimeMs)
    }
    state.lastSeenMtimeByFile = nextLastSeen
    state.changedFiles = changed

    if (!state.selectedSymbol || !state.items.some((x) => x.symbol === state.selectedSymbol)) {
      state.selectedSymbol = state.symbols[0]?.symbol || null
    }
    if (
      !state.selectedFileName ||
      !state.items.some((x) => x.fileName === state.selectedFileName && x.symbol === state.selectedSymbol)
    ) {
      const latest =
        state.items
          .filter((x) => x.symbol === state.selectedSymbol)
          .slice()
          .sort((a, b) => b.mtimeMs - a.mtimeMs)[0] || null
      state.selectedFileName = latest?.fileName || null
    }

    renderList()
    renderVersionSelect()
    renderAnalysis()
    void loadSavedAnalysis(state.selectedFileName)
  } catch (e) {
    setError(e instanceof Error ? e.message : t('refreshFailed'))
  }
}

async function analyze(fileName, expectedMtimeMs) {
  const key = analysisKey(fileName)
  const prev = state.analysisByFile.get(key)
  if (prev?.status === 'loading') return
  if (prev?.status === 'ready' && prev?.mtimeMs === expectedMtimeMs) return

  state.analysisByFile.set(key, { status: 'loading', mtimeMs: expectedMtimeMs })
  renderAnalysis()

  try {
    const res = await fetch('/api/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fileName, lang: state.lang }),
    })
    const data = await res.json().catch(() => null)
    if (!res.ok) throw new Error(data?.error || `${t('analyzeFailed')}: ${res.status}`)
    state.analysisByFile.set(key, { status: 'ready', mtimeMs: expectedMtimeMs, data })
  } catch (e) {
    state.analysisByFile.set(key, {
      status: 'error',
      mtimeMs: expectedMtimeMs,
      error: e instanceof Error ? e.message : t('analyzeFailed'),
    })
  }

  renderAnalysis()
}

function schedule() {
  if (state.timer) window.clearInterval(state.timer)
  const min = Math.max(1, Math.min(240, Number(els.intervalSec.value || 15)))
  els.intervalSec.value = String(min)
  state.timer = window.setInterval(async () => {
    if (!els.autoRefresh.checked) return
    await refresh()
    if (!els.autoAnalyze.checked) return
    if (state.changedFiles.size === 0) return
    if (state.analyzing) return
    state.analyzing = true
    try {
      for (const it of state.items) {
        if (!state.changedFiles.has(it.fileName)) continue
        const prev = state.analysisByFile.get(analysisKey(it.fileName))
        const need = !prev || prev.status !== 'ready' || prev.mtimeMs !== it.mtimeMs
        if (!need) continue
        await analyze(it.fileName, it.mtimeMs)
      }
    } finally {
      state.changedFiles.clear()
      state.analyzing = false
    }
  }, min * 60 * 1000)
}

els.refreshBtn.addEventListener('click', () => refresh())
els.intervalSec.addEventListener('change', () => schedule())
els.autoRefresh.addEventListener('change', () => schedule())
els.autoAnalyze.addEventListener('change', () => schedule())
if (els.versionSelect) {
  els.versionSelect.addEventListener('change', () => {
    const v = String(els.versionSelect.value || '')
    if (!v) return
    selectFile(v)
  })
}

if (els.langSelect) {
  els.langSelect.addEventListener('change', () => {
    const v = String(els.langSelect.value || '')
    setLanguage(v)
  })
}

els.analyzeBtn.addEventListener('click', async () => {
  const it = state.items.find((x) => x.fileName === state.selectedFileName) || null
  if (!it) return
  await analyze(it.fileName, it.mtimeMs)
})

;(async () => {
  await loadConfig()
  setLanguage(detectInitialLang())
  await refresh()
  schedule()
})()
