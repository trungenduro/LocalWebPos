import dotenv from 'dotenv'
import express from 'express'
import fs from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { GoogleGenAI } from '@google/genai'
import { openDb } from './db.js'
import {
  buildFacebookCaption,
  getFacebookConfig,
  isFacebookEnabled,
  postScreenshotToFacebookPage,
} from './facebook.js'

dotenv.config()

const app = express()
app.use(express.json({ limit: '15mb' }))

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const store = await openDb({ baseDir: __dirname })

const DEFAULT_SCREENSHOT_DIR = path.join(
  process.env.USERPROFILE ?? 'C:\\Users\\Administrator',
  'AppData',
  'Roaming',
  'MetaQuotes',
  'Terminal',
  'Common',
  'Files',
  'ScreenShot',
)

function getScreenshotDir() {
  const fromEnv = (process.env.SCREENSHOT_DIR || '').trim()
  return fromEnv.length > 0 ? fromEnv : DEFAULT_SCREENSHOT_DIR
}

function isSafeFileName(fileName) {
  if (typeof fileName !== 'string') return false
  if (!fileName.toLowerCase().endsWith('.png')) return false
  if (fileName.includes('/') || fileName.includes('\\')) return false
  if (fileName.includes('..')) return false
  return true
}

function parseScreenshotFileName(fileName) {
  const m = /^([^_]+)_([^_]+)_(\d{8})_(\d{6})\.png$/i.exec(fileName)
  if (m) {
    const [, symbol, timeframe, ymd, hms] = m
    const y = ymd.slice(0, 4)
    const mo = ymd.slice(4, 6)
    const d = ymd.slice(6, 8)
    const hh = hms.slice(0, 2)
    const mm = hms.slice(2, 4)
    const ss = hms.slice(4, 6)
    return {
      symbol,
      timeframe,
      capturedAt: `${y}-${mo}-${d}T${hh}:${mm}:${ss}`,
    }
  }

  const m2 = /^([^_]+)_(\d{8})_(\d{6})\.png$/i.exec(fileName)
  if (m2) {
    const [, symbol, ymd, hms] = m2
    const y = ymd.slice(0, 4)
    const mo = ymd.slice(4, 6)
    const d = ymd.slice(6, 8)
    const hh = hms.slice(0, 2)
    const mm = hms.slice(2, 4)
    const ss = hms.slice(4, 6)
    return {
      symbol,
      timeframe: 'NA',
      capturedAt: `${y}-${mo}-${d}T${hh}:${mm}:${ss}`,
    }
  }

  return { symbol: 'UNKNOWN', timeframe: 'NA', capturedAt: null }
}

async function listScreenshots() {
  const folder = getScreenshotDir()
  let entries = []
  try {
    entries = await fs.readdir(folder)
  } catch {
    return { folder, items: [] }
  }

  const items = []
  for (const fileName of entries) {
    if (!fileName.toLowerCase().endsWith('.png')) continue
    try {
      const stat = await fs.stat(path.join(folder, fileName))
      items.push({
        fileName,
        ...parseScreenshotFileName(fileName),
        mtimeMs: stat.mtimeMs,
      })
    } catch {
      continue
    }
  }

  items.sort((a, b) => b.mtimeMs - a.mtimeMs)
  return { folder, items }
}

function normalizeJsonText(text) {
  const t = String(text ?? '').trim()
  if (t.startsWith('```')) {
    const stripped = t.replace(/^```[a-zA-Z]*\s*/i, '').replace(/```$/, '')
    return stripped.trim()
  }
  return t
}

function coerceDirection(value) {
  if (value === 'long' || value === 'short' || value === 'neutral') return value
  return 'neutral'
}

function parseModelJson(rawText) {
  const base = {
    summary: String(rawText ?? '').slice(0, 600),
    currentWave: 'unknown',
    alternateCount: null,
    entryPlan: { direction: 'neutral', entry: 'n/a', invalidation: 'n/a', target: 'n/a' },
    confidence: 0.3,
  }

  try {
    const parsed = JSON.parse(normalizeJsonText(rawText))
    return {
      summary: typeof parsed.summary === 'string' ? parsed.summary : base.summary,
      currentWave:
        typeof parsed.currentWave === 'string' ? parsed.currentWave : base.currentWave,
      alternateCount:
        typeof parsed.alternateCount === 'string' ? parsed.alternateCount : null,
      entryPlan: {
        direction: coerceDirection(parsed?.entryPlan?.direction),
        entry:
          typeof parsed?.entryPlan?.entry === 'string'
            ? parsed.entryPlan.entry
            : base.entryPlan.entry,
        invalidation:
          typeof parsed?.entryPlan?.invalidation === 'string'
            ? parsed.entryPlan.invalidation
            : base.entryPlan.invalidation,
        target:
          typeof parsed?.entryPlan?.target === 'string'
            ? parsed.entryPlan.target
            : base.entryPlan.target,
      },
      confidence:
        typeof parsed.confidence === 'number'
          ? Math.max(0, Math.min(1, parsed.confidence))
          : base.confidence,
    }
  } catch {
    return base
  }
}

const analysisCache = new Map()

function getApiKey() {
  const key = (process.env.GOOGLE_API_KEY || process.env.GEMINI_API_KEY || '').trim()
  return key.length > 0 ? key : null
}

app.get('/api/health', (req, res) => {
  void req
  res.status(200).json({ success: true, message: 'ok' })
})

app.get('/api/config', (req, res) => {
  void req
  const raw = String(process.env.TIME_OFFSET_HOURS || '').trim()
  const n = raw.length > 0 ? Number(raw) : 0
  const timeOffsetHours = Number.isFinite(n) ? Math.max(-24, Math.min(24, n)) : 0
  res.status(200).json({ timeOffsetHours })
})

app.get('/api/screenshots', async (req, res) => {
  void req
  const data = await listScreenshots()
  res.status(200).json(data)
})

app.get('/api/screenshots/:fileName', async (req, res) => {
  const fileName = String(req.params.fileName ?? '')
  if (!isSafeFileName(fileName)) {
    res.status(400).json({ success: false, error: 'Invalid file name' })
    return
  }
  const abs = path.join(getScreenshotDir(), fileName)
  res.sendFile(abs, (err) => {
    if (err) res.status(404).json({ success: false, error: 'File not found' })
  })
})

app.get('/api/analysis/:fileName', async (req, res) => {
  const fileName = String(req.params.fileName ?? '')
  if (!isSafeFileName(fileName)) {
    res.status(400).json({ success: false, error: 'Invalid file name' })
    return
  }
  const langRaw = String(req.query?.lang ?? 'vi').toLowerCase()
  const lang = langRaw === 'en' || langRaw === 'ja' ? langRaw : 'vi'
  if (!store.enabled) {
    res.status(503).json({ success: false, error: 'SQLite chưa sẵn sàng' })
    return
  }
  const row = store.getByFile(fileName, lang)
  if (!row) {
    res.status(404).json({ success: false, error: 'Not found' })
    return
  }
  const value = {
    fileName: row.fileName,
    symbol: row.symbol,
    timeframe: row.timeframe,
    lang: row.lang,
    model: row.model,
    summary: row.summary,
    currentWave: row.currentWave,
    alternateCount: row.alternateCount,
    entryPlan: {
      direction: row.direction,
      entry: row.entry,
      invalidation: row.invalidation,
      target: row.target,
    },
    confidence: row.confidence,
    rawText: row.rawText,
    mtimeMs: row.mtimeMs,
    analyzedAt: row.analyzedAt,
    fbPostId: row.fbPostId ?? null,
    fbPostedAt: row.fbPostedAt ?? null,
  }
  res.status(200).json(value)
})

app.post('/api/analyze', async (req, res) => {
  const fileName = String(req.body?.fileName ?? '')
  if (!isSafeFileName(fileName)) {
    res.status(400).json({ success: false, error: 'Invalid file name' })
    return
  }
  const langRaw = String(req.body?.lang ?? 'vi').toLowerCase()
  const lang = langRaw === 'en' || langRaw === 'ja' ? langRaw : 'vi'

  const apiKey = getApiKey()
  if (!apiKey) {
    res.status(400).json({ success: false, error: 'Missing GOOGLE_API_KEY' })
    return
  }

  try {
    const folder = getScreenshotDir()
    const abs = path.join(folder, fileName)
    const stat = await fs.stat(abs)

    const cacheKey = `${lang}:${fileName}`
    const stored = store.enabled ? store.getByFile(fileName, lang) : null
    if (stored && Number(stored.mtimeMs) === Number(stat.mtimeMs)) {
      const value = {
        fileName: stored.fileName,
        symbol: stored.symbol,
        timeframe: stored.timeframe,
        lang: stored.lang,
        model: stored.model,
        summary: stored.summary,
        currentWave: stored.currentWave,
        alternateCount: stored.alternateCount,
        entryPlan: {
          direction: stored.direction,
          entry: stored.entry,
          invalidation: stored.invalidation,
          target: stored.target,
        },
        confidence: stored.confidence,
        rawText: stored.rawText,
        fbPostId: stored.fbPostId ?? null,
        fbPostedAt: stored.fbPostedAt ?? null,
      }
      analysisCache.set(cacheKey, { mtimeMs: stat.mtimeMs, value })
      res.status(200).json(value)
      return
    }

    const cached = analysisCache.get(cacheKey)
    if (cached && cached.mtimeMs === stat.mtimeMs) {
      res.status(200).json(cached.value)
      return
    }

    const model = (process.env.GEMINI_MODEL || '').trim() || 'gemini-3-flash-preview'
    const base64 = (await fs.readFile(abs)).toString('base64')
    const languageInstruction =
      lang === 'ja'
        ? 'Tất cả nội dung string (summary/currentWave/entry/invalidation/target/alternateCount) viết bằng TIẾNG NHẬT.'
        : lang === 'en'
          ? 'All string fields (summary/currentWave/entry/invalidation/target/alternateCount) must be written in ENGLISH.'
          : 'Tất cả nội dung string (summary/currentWave/entry/invalidation/target/alternateCount) viết bằng TIẾNG VIỆT.'
    const prompt = [
      'Bạn là chuyên gia phân tích Elliott Wave.',
      'Hãy phân tích ảnh chụp biểu đồ và suy ra kịch bản sóng hợp lý nhất, xác định hiện tại đang chạy sóng nào.',
      'Sau đó đề xuất kế hoạch vào lệnh thực tế dựa trên bối cảnh hiện tại.',
      languageInstruction,
      '',
      'Chỉ trả về JSON hợp lệ theo schema sau (KHÔNG thêm chữ khác):',
      '{',
      '  "summary": string,',
      '  "currentWave": string,',
      '  "alternateCount": string | null,',
      '  "entryPlan": { "direction": "long"|"short"|"neutral", "entry": string, "invalidation": string, "target": string },',
      '  "confidence": number (0..1)',
      '}',
      '',
      'Nếu ảnh không rõ, đặt direction="neutral" và confidence thấp.',
    ].join('\n')

    const ai = new GoogleGenAI({ apiKey })
    const response = await ai.models.generateContent({
      model,
      contents: [
        { inlineData: { mimeType: 'image/png', data: base64 } },
        { text: prompt },
      ],
      config: { responseMimeType: 'application/json' },
    })

    const rawText = response.text
    const parsed = parseScreenshotFileName(fileName)
    const value = {
      fileName,
      symbol: parsed.symbol,
      timeframe: parsed.timeframe,
      lang,
      model,
      ...parseModelJson(rawText),
      rawText,
      fbPostId: null,
      fbPostedAt: null,
    }

    if (store.enabled) {
      await store.upsert({
        fileName,
        symbol: value.symbol,
        timeframe: value.timeframe,
        lang: value.lang,
        mtimeMs: Math.trunc(stat.mtimeMs),
        analyzedAt: Date.now(),
        model: value.model,
        summary: value.summary,
        currentWave: value.currentWave,
        alternateCount: value.alternateCount ?? null,
        direction: value.entryPlan.direction,
        entry: value.entryPlan.entry,
        invalidation: value.entryPlan.invalidation,
        target: value.entryPlan.target,
        confidence: value.confidence,
        rawText: value.rawText,
        fbPostId: null,
        fbPostedAt: null,
      })
    }

    if (isFacebookEnabled()) {
      const fb = getFacebookConfig()
      if (fb.pageId && fb.pageAccessToken) {
        try {
          const caption = buildFacebookCaption({ analysis: value })
          const result = await postScreenshotToFacebookPage({
            fileName,
            absPath: abs,
            caption,
            pageId: fb.pageId,
            pageAccessToken: fb.pageAccessToken,
            apiVersion: fb.apiVersion,
          })

          const fbPostId = result?.post_id || result?.id || null
          const fbPostedAt = Date.now()
          value.fbPostId = fbPostId
          value.fbPostedAt = fbPostedAt

          if (store.enabled) {
            await store.upsert({
              fileName,
              symbol: value.symbol,
              timeframe: value.timeframe,
              lang: value.lang,
              mtimeMs: Math.trunc(stat.mtimeMs),
              analyzedAt: Date.now(),
              model: value.model,
              summary: value.summary,
              currentWave: value.currentWave,
              alternateCount: value.alternateCount ?? null,
              direction: value.entryPlan.direction,
              entry: value.entryPlan.entry,
              invalidation: value.entryPlan.invalidation,
              target: value.entryPlan.target,
              confidence: value.confidence,
              rawText: value.rawText,
              fbPostId,
              fbPostedAt,
            })
          }
        } catch {
          void 0
        }
      }
    }

    analysisCache.set(cacheKey, { mtimeMs: stat.mtimeMs, value })
    res.status(200).json(value)
  } catch (e) {
    res.status(400).json({
      success: false,
      error: e instanceof Error ? e.message : 'Phân tích thất bại',
    })
  }
})

app.use(express.static(path.join(__dirname, 'public')))

app.get('*', (req, res) => {
  void req
  res.sendFile(path.join(__dirname, 'public', 'index.html'))
})

const port = Number(process.env.PORT || 3000)
app.listen(port, () => {
  process.stdout.write(`Wave Desk running on http://localhost:${port}/\n`)
})
