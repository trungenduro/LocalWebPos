# Wave Desk (Node.js + HTML)

Local web app that:
- Lists MetaTrader 5 screenshots (by reading `Terminal\\Common\\Files\\ScreenShot`)
- Lets you click a screenshot and send it to Gemini for Elliott Wave analysis (current wave + entry plan)

## Setup

1. Install dependencies:

```bash
npm install
```

2. Create `.env` (copy from `.env.example`) and set:
- `GOOGLE_API_KEY`
- `SCREENSHOT_DIR` (optional)
- `GEMINI_MODEL` (optional)

## Run

```bash
npm run dev
```

Open:
- http://localhost:3000/

## PM2

1. Cài PM2 (1 lần):

```bash
npm i -g pm2
```

2. Start app:

```bash
pm2 start ecosystem.config.cjs
pm2 save
```

Các lệnh nhanh:

```bash
npm run pm2:restart
npm run pm2:logs
npm run pm2:stop
```

## Facebook Page (tự động đăng bài kèm ảnh)

App có thể tự đăng kết quả phân tích lên Facebook Page khi có ảnh mới (chỉ chạy khi bạn bật `FB_POST_ENABLED=1` và đã có token hợp lệ).

### 1) Lấy Page ID
- Mở Page → About/Thông tin → Page ID

### 2) Lấy Page Access Token
- Tạo Facebook App trên Meta for Developers
- Thêm sản phẩm Facebook Login + Graph API
- Dùng Graph API Explorer:
  - Lấy User Access Token có quyền `pages_manage_posts`, `pages_read_engagement`, `pages_show_list`
  - Đổi sang Page Access Token cho Page của bạn

### 3) Cấu hình .env
Trong `.env`:
- `FB_POST_ENABLED=1`
- `FB_PAGE_ID=...`
- `FB_PAGE_ACCESS_TOKEN=...`

Ghi chú:
- Không commit token lên git.
