import fs from 'node:fs/promises'
import path from 'node:path'
import initSqlJs from 'sql.js'

function cleanPath(s) {
  const t = String(s || '').trim()
  if ((t.startsWith('"') && t.endsWith('"')) || (t.startsWith("'") && t.endsWith("'"))) {
    return t.slice(1, -1).trim()
  }
  return t
}

export async function openDb({ baseDir }) {
  const fromEnv = cleanPath(process.env.ANALYSIS_DB)
  const fallback = path.join(baseDir, 'data', 'wave-desk.sqlite')
  const candidates = []
  if (fromEnv.length > 0) candidates.push(fromEnv)
  candidates.push(fallback)

  for (const dbPath of candidates) {
    try {
      await fs.mkdir(path.dirname(dbPath), { recursive: true })
      const SQL = await initSqlJs({
        locateFile: (file) => path.join(baseDir, 'node_modules', 'sql.js', 'dist', file),
      })

      let dbFile = null
      try {
        dbFile = await fs.readFile(dbPath)
      } catch {
        dbFile = null
      }

      const db = dbFile ? new SQL.Database(new Uint8Array(dbFile)) : new SQL.Database()

      async function persist() {
        const data = db.export()
        await fs.writeFile(dbPath, Buffer.from(data))
      }

      db.exec(`
        CREATE TABLE IF NOT EXISTS analyses (
          fileName TEXT NOT NULL,
          symbol TEXT,
          timeframe TEXT,
          lang TEXT NOT NULL,
          mtimeMs INTEGER,
          analyzedAt INTEGER,
          model TEXT,
          summary TEXT,
          currentWave TEXT,
          alternateCount TEXT,
          direction TEXT,
          entry TEXT,
          invalidation TEXT,
          target TEXT,
          confidence REAL,
          rawText TEXT,
          fbPostId TEXT,
          fbPostedAt INTEGER,
          PRIMARY KEY (fileName, lang)
        );
        CREATE INDEX IF NOT EXISTS idx_analyses_symbol ON analyses(symbol);
        CREATE INDEX IF NOT EXISTS idx_analyses_mtime ON analyses(mtimeMs);
      `)

      function getTableInfo() {
        const r = db.exec('PRAGMA table_info(analyses)')
        if (!r || r.length === 0) return []
        const cols = r[0].columns
        return r[0].values.map((values) => {
          const obj = {}
          for (let i = 0; i < cols.length; i += 1) obj[cols[i]] = values[i]
          return obj
        })
      }

      const info = getTableInfo()
      const cols = new Set(info.map((x) => String(x.name)))
      const pkCols = info
        .filter((x) => Number(x.pk) > 0)
        .slice()
        .sort((a, b) => Number(a.pk) - Number(b.pk))
        .map((x) => String(x.name))
      const hasLang = cols.has('lang')
      const hasCompositePk =
        pkCols.length === 2 && pkCols[0] === 'fileName' && pkCols[1] === 'lang'
      let altered = false
      if (!cols.has('fbPostId')) {
        db.exec('ALTER TABLE analyses ADD COLUMN fbPostId TEXT')
        altered = true
      }
      if (!cols.has('fbPostedAt')) {
        db.exec('ALTER TABLE analyses ADD COLUMN fbPostedAt INTEGER')
        altered = true
      }
      if (altered) await persist()

      if (!hasLang || !hasCompositePk) {
        db.exec(`
          CREATE TABLE IF NOT EXISTS analyses_v2 (
            fileName TEXT NOT NULL,
            symbol TEXT,
            timeframe TEXT,
            lang TEXT NOT NULL,
            mtimeMs INTEGER,
            analyzedAt INTEGER,
            model TEXT,
            summary TEXT,
            currentWave TEXT,
            alternateCount TEXT,
            direction TEXT,
            entry TEXT,
            invalidation TEXT,
            target TEXT,
            confidence REAL,
            rawText TEXT,
            fbPostId TEXT,
            fbPostedAt INTEGER,
            PRIMARY KEY (fileName, lang)
          );
        `)

        if (!hasLang) {
          db.exec(`
            INSERT OR REPLACE INTO analyses_v2 (
              fileName, symbol, timeframe, lang, mtimeMs, analyzedAt, model,
              summary, currentWave, alternateCount,
              direction, entry, invalidation, target,
              confidence, rawText, fbPostId, fbPostedAt
            )
            SELECT
              fileName, symbol, timeframe, 'vi' as lang, mtimeMs, analyzedAt, model,
              summary, currentWave, alternateCount,
              direction, entry, invalidation, target,
              confidence, rawText, fbPostId, fbPostedAt
            FROM analyses
          `)
        } else {
          db.exec(`
            INSERT OR REPLACE INTO analyses_v2 (
              fileName, symbol, timeframe, lang, mtimeMs, analyzedAt, model,
              summary, currentWave, alternateCount,
              direction, entry, invalidation, target,
              confidence, rawText, fbPostId, fbPostedAt
            )
            SELECT
              fileName, symbol, timeframe, COALESCE(NULLIF(lang,''),'vi') as lang, mtimeMs, analyzedAt, model,
              summary, currentWave, alternateCount,
              direction, entry, invalidation, target,
              confidence, rawText, fbPostId, fbPostedAt
            FROM analyses
          `)
        }

        db.exec(`
          DROP TABLE analyses;
          ALTER TABLE analyses_v2 RENAME TO analyses;
          DROP INDEX IF EXISTS idx_analyses_symbol;
          DROP INDEX IF EXISTS idx_analyses_mtime;
          DROP INDEX IF EXISTS idx_analyses_lang;
          CREATE INDEX IF NOT EXISTS idx_analyses_symbol ON analyses(symbol);
          CREATE INDEX IF NOT EXISTS idx_analyses_mtime ON analyses(mtimeMs);
          CREATE INDEX IF NOT EXISTS idx_analyses_lang ON analyses(lang);
        `)
        await persist()
      }

      db.exec('CREATE INDEX IF NOT EXISTS idx_analyses_lang ON analyses(lang)')

      function getByFile(fileName, lang) {
        const stmt = db.prepare('SELECT * FROM analyses WHERE fileName = ? AND lang = ?')
        stmt.bind([fileName, lang])
        if (!stmt.step()) return null
        const row = stmt.getAsObject()
        stmt.free()
        return row
      }

      async function upsert(row) {
        db.run(
          `
          INSERT INTO analyses (
            fileName, symbol, timeframe, lang, mtimeMs, analyzedAt, model,
            summary, currentWave, alternateCount,
            direction, entry, invalidation, target,
            confidence, rawText, fbPostId, fbPostedAt
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          ON CONFLICT(fileName, lang) DO UPDATE SET
            symbol=excluded.symbol,
            timeframe=excluded.timeframe,
            lang=excluded.lang,
            mtimeMs=excluded.mtimeMs,
            analyzedAt=excluded.analyzedAt,
            model=excluded.model,
            summary=excluded.summary,
            currentWave=excluded.currentWave,
            alternateCount=excluded.alternateCount,
            direction=excluded.direction,
            entry=excluded.entry,
            invalidation=excluded.invalidation,
            target=excluded.target,
            confidence=excluded.confidence,
            rawText=excluded.rawText,
            fbPostId=excluded.fbPostId,
            fbPostedAt=excluded.fbPostedAt
        `,
          [
            row.fileName,
            row.symbol,
            row.timeframe,
            row.lang,
            row.mtimeMs,
            row.analyzedAt,
            row.model,
            row.summary,
            row.currentWave,
            row.alternateCount,
            row.direction,
            row.entry,
            row.invalidation,
            row.target,
            row.confidence,
            row.rawText,
            row.fbPostId ?? null,
            row.fbPostedAt ?? null,
          ],
        )
        await persist()
      }

      return {
        enabled: true,
        dbPath,
        getByFile,
        upsert,
      }
    } catch (e) {
      process.stderr.write(
        `SQLite init failed for ${dbPath}: ${e instanceof Error ? e.message : String(e)}\n`,
      )
      continue
    }
  }

  return {
    enabled: false,
    dbPath: null,
    getByFile: () => null,
    upsert: () => null,
  }
}
